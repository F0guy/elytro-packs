#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

// Elytro rank shine (dev-hud/shine). Text whose colour carries the marker in its low bits
// (R&7 = 6, G&7 = 1, B&7 = 4) keeps that colour and gets a soft bright band sweeping across it.
// Legacy colours (00/55/AA/FF) can never match. Shadows are colour/4, lose the marker, stay still.
vec4 elyShine(vec4 color, vec4 clipPos) {
    ivec3 c = ivec3(round(color.rgb * 255.0));
    if ((c.r & 7) != 6 || (c.g & 7) != 1 || (c.b & 7) != 4) return color;
    float k = max(ScreenSize.y, 1.0) / 1080.0;
    float px = (clipPos.x / clipPos.w * 0.5 + 0.5) * ScreenSize.x;
    float span = 640.0 * k;                       // one band every 640 px (at 1080p)
    float t = GameTime * 1200.0;                  // seconds; wraps every 20 min, 2.5 s divides it
    float d = mod(px - (t / 2.5) * span, span);
    d = min(d, span - d);
    float w = 34.0 * k;
    float glow = exp(-(d * d) / (w * w));
    return vec4(mix(color.rgb, mix(color.rgb, vec3(1.0), 0.62), glow), color.a);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = elyShine(Color, gl_Position) * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = elyShine(Color, gl_Position);
#endif
    texCoord0 = UV0;
}
