"""Elytro Music Manager: local imports/conversion, pack export and verified live activation."""
from pathlib import Path
import concurrent.futures,contextlib,hashlib,io,json,math,os,re,secrets,shutil,socket,subprocess,sys,threading,time,urllib.request,urllib.parse,webbrowser,zipfile
from flask import Flask,request,jsonify,render_template,send_from_directory,abort
import imageio_ffmpeg,soundfile as sf
ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parent
sys.path.insert(0,str(WORKSPACE/'tools'))
import sftp,rcon
BASE_URL='https://raw.githubusercontent.com/F0guy/elytro-packs/main/'
PORT=5719
app=Flask(__name__);app.config['MAX_CONTENT_LENGTH']=150*1024*1024
TOKEN=secrets.token_urlsafe(32)
POOL=concurrent.futures.ThreadPoolExecutor(max_workers=2)
JOBS={};LOCK=threading.RLock()
for name in ['data/tracks','data/jobs','exports']: (ROOT/name).mkdir(parents=True,exist_ok=True)
LIB=ROOT/'data/library.json'

def library():return json.loads(LIB.read_text(encoding='utf-8')) if LIB.exists() else {'tracks':{}}
def save_library(value):
 tmp=LIB.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2),encoding='utf-8');os.replace(tmp,LIB)
def valid_id(value):
 if not re.fullmatch('[a-z][a-z0-9_]{1,47}',value or ''):raise ValueError('Use a short track ID made of lowercase letters, numbers and underscores.')
 return value
def public_track(t):return {k:v for k,v in t.items() if k not in ['source']}
def job(fn,*args):
 key=secrets.token_hex(8);JOBS[key]={'status':'working','message':'Starting…'}
 def go():
  try:JOBS[key]={'status':'done','result':fn(*args)}
  except Exception as e:JOBS[key]={'status':'error','message':str(e)[:500]}
 POOL.submit(go);return key

def fetch(url):
 req=urllib.request.Request(url,headers={'User-Agent':'Elytro-Music-Manager','Cache-Control':'no-cache'})
 with urllib.request.urlopen(req,timeout=60) as response:
  if int(response.headers.get('Content-Length','0'))>150*1024*1024:raise ValueError('File is larger than 150 MB.')
  b=response.read(150*1024*1024+1)
 if len(b)>150*1024*1024:raise ValueError('File is larger than 150 MB.')
 return b

def console(command):
 conf=json.loads(Path(rcon.CONF).read_text(encoding='utf-8-sig'));host=conf['host'].strip().split(':')[0]
 with socket.create_connection((host,int(conf['port'])),timeout=20) as sock:
  sock.sendall(rcon.packet(1,3,conf['password']));rid,_,_=rcon.read_packet(sock)
  if rid==-1:raise ValueError('The saved server console login was rejected.')
  sock.sendall(rcon.packet(2,2,command));_,_,body=rcon.read_packet(sock)
 return rcon.strip_colours(body)

def convert(source,track_id,title,artist):
 valid_id(track_id)
 if not title.strip():raise ValueError('Enter the track title.')
 with LOCK:
  if track_id in library()['tracks']:raise ValueError('That track ID already exists. Choose a new ID to keep existing discs working.')
 target=ROOT/'data/tracks'/f'{track_id}.ogg';temporary=target.with_name(track_id+'.'+secrets.token_hex(4)+'.working.ogg')
 result=subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-nostdin','-hide_banner','-loglevel','error','-y','-i',str(source),'-vn','-ac','1','-ar','44100','-t','1800','-af','loudnorm=I=-18:TP=-1.5:LRA=11','-c:a','libvorbis','-q:a','5',str(temporary)],capture_output=True,text=True,timeout=300)
 if result.returncode:raise ValueError('That file could not be converted to audio. Try MP3, WAV, FLAC, M4A or OGG.')
 info=sf.info(temporary)
 if info.duration<=0 or info.channels!=1 or info.subtype!='VORBIS':raise ValueError('The converted file did not pass the OGG Vorbis check.')
 row={'id':track_id,'title':title.strip()[:90],'artist':artist.strip()[:90] or 'Elytro','duration':math.ceil(info.duration),'seconds':round(info.duration,3),'sample_rate':info.samplerate,'channels':1,'sha256':hashlib.sha256(temporary.read_bytes()).hexdigest()}
 with LOCK:
  data=library()
  if track_id in data['tracks']:raise ValueError('Another import just used that track ID. Choose another.')
  os.replace(temporary,target);data['tracks'][track_id]=row;save_library(data)
 return row

def download(url,track_id,title,artist):
 if not urllib.parse.urlparse(url).scheme in ['http','https']:raise ValueError('Use a full http:// or https:// media link.')
 folder=ROOT/'data/jobs'/secrets.token_hex(8);folder.mkdir()
 # yt-dlp accepts both direct audio links and supported media pages; no playlist downloads.
 cmd=[sys.executable,'-m','yt_dlp','--no-playlist','--no-warnings','--socket-timeout','20','--retries','2','--max-filesize','150M','-f','bestaudio/best','-o',str(folder/'source.%(ext)s'),'--',url]
 done=subprocess.run(cmd,capture_output=True,text=True,timeout=300)
 files=[p for p in folder.iterdir() if p.is_file() and p.suffix not in ['.part','.ytdl']]
 if done.returncode or not files:raise ValueError('The download did not finish. You can also upload a local audio file.')
 return convert(files[0],track_id,title,artist)

def zip_bytes(files):
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(files.items()):
   info=zipfile.ZipInfo(n,(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,b)
 return buf.getvalue()
def unzip(b):
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  if z.testzip():raise ValueError('A pack ZIP failed its integrity check.')
  return {n:z.read(n) for n in z.namelist() if not n.endswith('/')}

def prepare():
 with LOCK:tracks=library()['tracks'].copy()
 if not tracks:raise ValueError('Import a track first.')
 c,ch,r=sftp.connect()
 try:
  with ch.open(sftp.remote(r,'plugins/ElyEmojis/config.yml'),'rb') as f:cfg=f.read().decode('utf-8-sig')
  try:
   with ch.open(sftp.remote(r,'plugins/Skript/music/catalog.yml'),'rb') as f:old_catalog=f.read()
  except FileNotFoundError:old_catalog=None
  if old_catalog:
   prior=json.loads(old_catalog.decode('utf-8-sig'))['tracks']
   for tid,row in prior.items():
    if tid in tracks and tracks[tid]['sha256']!=row['sha256']:raise ValueError('Track ID already exists on the server: '+tid)
   tracks={**prior,**tracks}
 finally:ch.close();c.close()
 old_url=re.search(r'^  url: [\"\']([^\"\']+)',cfg,re.M)[1];old_sha=re.search(r'^  sha1: [\"\']([0-9a-f]{40})',cfg,re.M)[1]
 original=fetch(old_url)
 if hashlib.sha1(original).hexdigest()!=old_sha:raise ValueError('The server pack link and hash do not match. Leave it unchanged until corrected.')
 files=unzip(original);sounds={}
 if 'assets/elytromusic/sounds.json' in files:sounds=json.loads(files['assets/elytromusic/sounds.json'])
 assets={n:b for n,b in files.items() if n.startswith('assets/elytromusic/')};songs={}
 for tid,t in tracks.items():
  local=ROOT/'data/tracks'/f'{tid}.ogg'
  audio=local.read_bytes() if local.exists() else files[f'assets/elytromusic/sounds/{tid}.ogg']
  if hashlib.sha256(audio).hexdigest()!=t['sha256']:raise ValueError('An audio file changed after import: '+tid)
  assets[f'assets/elytromusic/sounds/{tid}.ogg']=audio
  definition={'sounds':[{'name':'elytromusic:'+tid,'stream':True}],'subtitle':'musicDisc.custom'}
  sounds[tid]=definition;sounds['preview.'+tid]=definition
  for voice in range(32):sounds['jukebox'+str(voice)+'.'+tid]=definition
  songs[f'data/elytromusic/jukebox_song/{tid}.json']=json.dumps({'sound_event':{'sound_id':'elytromusic:'+tid,'range':64.0},'description':{'text':t['artist']+' — '+t['title']},'length_in_seconds':float(t['seconds']),'comparator_output':15},ensure_ascii=False).encode()
 assets['assets/elytromusic/sounds.json']=json.dumps(sounds,indent=2).encode()
 files.update(assets)
 folder=ROOT/'exports/current';folder.mkdir(exist_ok=True)
 (folder/'skin-pack.zip').write_bytes(zip_bytes(files));(folder/'music-sources.zip').write_bytes(zip_bytes(assets))
 songs['pack.mcmeta']=json.dumps({'pack':{'min_format':[94,1],'max_format':[94,1],'description':'Elytro custom jukebox songs'}}).encode()
 (folder/'elytro-music-datapack.zip').write_bytes(zip_bytes(songs))
 prepared={'old-url':old_url,'old-sha1':old_sha,'sha1':hashlib.sha1((folder/'skin-pack.zip').read_bytes()).hexdigest(),'tracks':tracks,'prepared':time.time(),'catalog-sha256':hashlib.sha256(old_catalog or b'').hexdigest(),'upload':['skin-pack.zip','music-sources.zip']}
 # Rebuild support is a tiny additive change to the latest source, never an old local copy.
 builder=fetch(BASE_URL+'build_merged.py').decode('utf-8-sig')
 if "music-sources.zip" not in builder:
  a=builder.index("    skin_sources = ");b=builder.index("    root = os.path.join(HERE, 'extra')",a)
  builder=builder[:a]+'''    skin_fallback = set()
    for source_name in ('skin-sources.zip', 'music-sources.zip'):
        source_path = os.path.join(HERE, source_name)
        if not os.path.isfile(source_path):
            continue
        with zipfile.ZipFile(source_path) as source:
            for name in source.namelist():
                if name.endswith('/'):
                    continue
                if not name.startswith(('assets/elytro/', 'assets/elytromusic/')) or '..' in name.split('/'):
                    sys.exit('Invalid source path: ' + name)
                body = source.read(name)
                if name in files and files[name] != body:
                    sys.exit('Source conflicts with boss/emoji asset: ' + name)
                files[name] = body
                skin_fallback.add(name)
'''+builder[b:]
  compile(builder,'build_merged.py','exec')
  (folder/'build_merged.py').write_text(builder,encoding='utf-8');prepared['upload'].append('build_merged.py')
 (folder/'build_merged.py').write_text(builder,encoding='utf-8')
 if 'build_merged.py' not in prepared['upload']:prepared['upload'].append('build_merged.py')
 (folder/'prepared.json').write_text(json.dumps(prepared,indent=2),encoding='utf-8')
 instructions='Upload these files to the ROOT of F0guy/elytro-packs on GitHub:\n'+'\n'.join(prepared['upload'])+'\n\nAfter committing, press Activate in the Music Manager. It verifies the download and installs the matching music catalog and script. Never upload server login files.\n'
 (folder/'UPLOAD-README.txt').write_text(instructions,encoding='utf-8')
 return {'sha1':prepared['sha1'],'files':prepared['upload'],'folder':str(folder),'tracks':len(tracks)}

def activate():
 folder=ROOT/'exports/current';p=json.loads((folder/'prepared.json').read_text())
 published=fetch(BASE_URL+'skin-pack.zip')
 if hashlib.sha1(published).hexdigest()!=p['sha1']:raise ValueError('GitHub is not serving the prepared pack yet. Upload the listed files and commit, then try Activate again.')
 if published!=(folder/'skin-pack.zip').read_bytes():raise ValueError('Published pack differs from the prepared file.')
 c,ch,r=sftp.connect()
 try:
  cfg_path='plugins/ElyEmojis/config.yml'
  try:
   with ch.open(sftp.remote(r,'plugins/Skript/music/catalog.yml'),'rb') as f:current_catalog=f.read()
  except FileNotFoundError:current_catalog=b''
  if hashlib.sha256(current_catalog).hexdigest()!=p['catalog-sha256']:
   # Re-activation is allowed only when the server already has this prepared catalog.
   if not current_catalog or json.loads(current_catalog.decode('utf-8-sig')).get('tracks')!=p['tracks']:raise ValueError('The music catalog changed; prepare a fresh update.')
  with ch.open(sftp.remote(r,cfg_path),'rb') as f:before=f.read()
  text=before.decode('utf-8-sig');old_sha=re.search(r'^  sha1: [\"\']([0-9a-f]{40})',text,re.M)[1]
  if old_sha not in [p['old-sha1'],p['sha1']]:raise ValueError('Someone changed the active pack. Prepare a fresh update to preserve their work.')
  with ch.open(sftp.remote(r,'server.properties'),'rb') as f:properties=f.read().decode('utf-8',errors='replace')
  world=re.search(r'^level-name=(.+)$',properties,re.M)[1].strip()
  if not re.fullmatch('[A-Za-z0-9_ -]+',world):raise ValueError('Unexpected main world path. Configure it before activation.')
  def mkdir(path):
   try:ch.mkdir(sftp.remote(r,path))
   except OSError:pass
  mkdir('plugins/Skript/music')
  cfg=re.sub(r'(?m)^  sha1: [^\r\n]*','  sha1: "'+p['sha1']+'"',text)
  cfg=re.sub(r'(?m)^  url: [^\r\n]*','  url: "'+BASE_URL+'skin-pack.zip"',cfg).encode('utf-8')
  catalog=json.dumps({'tracks':{k:public_track(v) for k,v in p['tracks'].items()}},ensure_ascii=False,indent=2).encode('utf-8')
  writes={'plugins/Skript/music/catalog.yml':catalog,'plugins/Skript/scripts/music_manager.sk':(ROOT/'server/music_manager.sk').read_bytes(),cfg_path:cfg}
  stamp=str(time.time_ns());staged=[]
  for target,data in writes.items():
   try:
    with ch.open(sftp.remote(r,target),'rb') as f:previous=f.read()
   except FileNotFoundError:previous=None
   if previous is not None:
    backup=sftp.storage_dir(ch,r,'elytro-deploy-backups')+'/'+stamp+'-music-'+target.replace('/','_')
    with ch.open(backup,'wb') as f:f.write(previous)
   staged.append((target,sftp.stage_bytes(ch,r,target,data),data,previous))
  for target,tmp,data,previous in staged:
   try:
    with ch.open(sftp.remote(r,target),'rb') as f:current=f.read()
   except FileNotFoundError:current=None
   if current!=previous:raise ValueError('A live file changed during upload. Prepare a fresh update.')
  for target,tmp,data,previous in staged:
   sftp.promote_staged(ch,r,target,tmp)
   with ch.open(sftp.remote(r,target),'rb') as f:
    if f.read()!=data:raise ValueError('Upload verification failed.')
 finally:ch.close();c.close()
 result=[console('sk reload music_manager')]
 if any('error' in x.lower() for x in result):raise ValueError('The server reported a script error. Check its console.')
 result.append(console('music reload'));result.append(console('emojis reload'))
 p['activated']=time.time();(folder/'prepared.json').write_text(json.dumps(p,indent=2))
 return {'message':'Tracks are live. The updated pack was offered to online players. Use /music or put a custom disc into a jukebox.','console':result}

@app.before_request
def local_only():
 if request.remote_addr not in ['127.0.0.1','::1']:abort(403)
 if request.host not in ['127.0.0.1:5719','localhost:5719']:abort(403)
 if request.method=='POST' and request.headers.get('X-CSRF-Token')!=TOKEN:abort(403)
@app.get('/')
def index():return render_template('index.html',token=TOKEN)
@app.get('/api/library')
def get_library():
 p=ROOT/'exports/current/prepared.json'
 return jsonify(tracks=list(library()['tracks'].values()),prepared=p.exists(),upload=json.loads(p.read_text()).get('upload',[]) if p.exists() else [])
@app.get('/api/jobs/<key>')
def get_job(key):return jsonify(JOBS.get(key,{'status':'error','message':'Job not found.'}))
@app.post('/api/import')
def import_audio():
 tid=valid_id(request.form.get('id',''));title=request.form.get('title','');artist=request.form.get('artist','');url=request.form.get('url','').strip()
 if url:return jsonify(job=job(download,url,tid,title,artist))
 upload=request.files.get('file')
 if not upload:raise ValueError('Choose an audio file or paste a download link.')
 source=ROOT/'data/jobs'/('upload-'+secrets.token_hex(8)+Path(upload.filename).suffix.lower());upload.save(source)
 return jsonify(job=job(convert,source,tid,title,artist))
@app.post('/api/open-folder')
def open_folder():
 path=ROOT/'exports/current';path.mkdir(exist_ok=True);os.startfile(path);return jsonify(ok=True)
@app.post('/api/prepare')
def prepare_route():return jsonify(job=job(prepare))
@app.post('/api/activate')
def activate_route():return jsonify(job=job(activate))
@app.get('/exports/<name>')
def export(name):
 if name not in ['skin-pack.zip','music-sources.zip','build_merged.py','UPLOAD-README.txt','elytro-music-datapack.zip']:abort(404)
 return send_from_directory(ROOT/'exports/current',name,as_attachment=True)
@app.get('/preview/<tid>')
def preview(tid):valid_id(tid);return send_from_directory(ROOT/'data/tracks',tid+'.ogg')
@app.errorhandler(ValueError)
def bad_input(e):return jsonify(error=str(e)),400
if __name__=='__main__':
 if '--open' in sys.argv:threading.Timer(1,lambda:webbrowser.open(f'http://127.0.0.1:{PORT}')).start()
 app.run(host='127.0.0.1',port=PORT,debug=False,threaded=True)
