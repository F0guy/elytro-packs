"""Minimal Minecraft RCON client.

Reads the connection from %USERPROFILE%\\.elytro-rcon.json (kept out of the project and out
of chat):

    {"host": "your.server.ip", "port": 25575, "password": "your-rcon-password"}

usage:  python tools/rcon.py "tpprobe last"      (no leading slash)
"""
import json
import os
import socket
import struct
import sys

CONF = os.path.join(os.path.expanduser('~'), '.elytro-rcon.json')


def packet(req_id, kind, body):
    data = struct.pack('<ii', req_id, kind) + body.encode('utf-8') + b'\x00\x00'
    return struct.pack('<i', len(data)) + data


def read_packet(sock):
    def exact(n):
        buf = b''
        while len(buf) < n:
            chunk = sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError('server closed the connection')
            buf += chunk
        return buf
    (length,) = struct.unpack('<i', exact(4))
    data = exact(length)
    req_id, kind = struct.unpack('<ii', data[:8])
    return req_id, kind, data[8:-2].decode('utf-8', errors='replace')


def strip_colours(s):
    out, skip = [], False
    for ch in s:
        if skip:
            skip = False
            continue
        if ch == '§':
            skip = True
            continue
        out.append(ch)
    return ''.join(out)


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')  # Paper replies use symbols like the info sign
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    if not os.path.exists(CONF):
        print('Missing ' + CONF + ' - create it with host, port and password (see the top of this file).')
        return 2
    conf = json.load(open(CONF, encoding='utf-8'))
    command = ' '.join(sys.argv[1:]).lstrip('/')
    host = conf['host'].strip()
    if host.count(':') == 1:  # "address:gameport" pasted from the panel - RCON uses "port" instead
        host = host.split(':')[0]
    port = int(os.environ.get('RCON_PORT') or conf.get('port', 25575))  # RCON_PORT overrides for a one-off
    with socket.create_connection((host, port), timeout=10) as sock:
        sock.sendall(packet(1, 3, conf['password']))          # 3 = login
        req_id, _, _ = read_packet(sock)
        if req_id == -1:
            print('RCON login failed - wrong password?')
            return 1
        sock.sendall(packet(2, 2, command))                    # 2 = command
        _, _, body = read_packet(sock)
        print(strip_colours(body) if body else '(no output)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
