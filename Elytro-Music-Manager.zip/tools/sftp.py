"""Minimal SFTP helper for the Elytro server.

Reads the connection from %USERPROFILE%\\.elytro-sftp.json (kept out of the project and out
of chat):

    {"host": "...", "port": 2022, "username": "...", "password": "...", "remote_root": "/"}

If ~/.ssh/elytro_sftp exists (or "key_file" points at a key) it logs in with that key
instead of the password.

usage:
    python tools/sftp.py ls  <remote-dir>
    python tools/sftp.py get <remote-file> <local-file>
    python tools/sftp.py put <local-file> <remote-file>    (backs the old remote copy up first)

Backups of anything overwritten go to tools/sftp-backups/<timestamp>/<remote path>.
The server's host key is remembered in %USERPROFILE%\\.elytro-sftp-known_hosts on first
connect and checked every time after that.
"""
import json
import os
import sys
import time
import hashlib
import posixpath
import stat
import uuid

import paramiko

CONF = os.path.join(os.path.expanduser('~'), '.elytro-sftp.json')
KNOWN = os.path.join(os.path.expanduser('~'), '.elytro-sftp-known_hosts')
BACKUPS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sftp-backups')


def connect():
    with open(CONF, encoding='utf-8-sig') as f:
        conf = json.load(f)
    host = conf['host'].split(':')[0].strip()
    port = int(conf.get('port', 2022))
    client = paramiko.SSHClient()
    if os.path.exists(KNOWN):
        client.load_host_keys(KNOWN)
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
    else:
        # first connect: trust and remember the key, then refuse any different key later
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    # an SSH key (added under Account -> SSH Keys in the panel) wins over the password
    key_file = os.path.expanduser(conf.get('key_file', '~/.ssh/elytro_sftp'))
    if os.path.exists(key_file):
        # key only - no silent password retry, so failures don't pile up toward a lockout
        client.connect(host, port=port, username=conf['username'], key_filename=key_file,
                       timeout=15, allow_agent=False, look_for_keys=False)
    else:
        client.connect(host, port=port, username=conf['username'], password=conf['password'],
                       timeout=15, allow_agent=False, look_for_keys=False)
    if not os.path.exists(KNOWN):
        client.save_host_keys(KNOWN)
        key = client.get_transport().get_remote_server_key()
        print('remembered host key', key.get_name(), key.get_fingerprint().hex())
    root = conf.get('remote_root', '/') or '/'
    return client, client.open_sftp(), root


def remote(root, path):
    path = path.replace('\\', '/')
    if path.startswith('/'):
        return path
    return root.rstrip('/') + '/' + path


def storage_dir(sftp, root, name):
    """Deployment artifacts must be outside plugins: Paper inspects update files as jars."""
    if name not in ('elytro-deploy-staging', 'elytro-deploy-backups'):
        raise ValueError('Unknown deployment storage directory')
    folder = remote(root, name)
    try:
        sftp.mkdir(folder)
    except OSError:
        if not stat.S_ISDIR(sftp.stat(folder).st_mode):
            raise
    return folder


def stage_bytes(sftp, root, target, data):
    folder = storage_dir(sftp, root, 'elytro-deploy-staging')
    temporary = posixpath.join(folder, uuid.uuid4().hex + '-' + posixpath.basename(target) + '.tmp')
    with sftp.open(temporary, 'wb') as output:
        output.write(data)
    with sftp.open(temporary, 'rb') as uploaded:
        uploaded.prefetch(file_size=uploaded.stat().st_size, max_concurrent_requests=32)
        if hashlib.sha256(uploaded.read()).digest() != hashlib.sha256(data).digest():
            raise IOError('Deployment upload verification failed: ' + target)
    return temporary


def promote_staged(sftp, root, target, temporary):
    """Publish a verified upload; retain fallback backups outside the plugin loader's paths."""
    folder = remote(root, 'elytro-deploy-staging').rstrip('/') + '/'
    if not temporary.startswith(folder) or '..' in temporary.split('/'):
        raise ValueError('Upload must be in the dedicated staging directory')
    target = remote(root, target)
    try:
        sftp.posix_rename(temporary, target)
        return
    except OSError:
        pass
    backups = storage_dir(sftp, root, 'elytro-deploy-backups')
    previous = posixpath.join(backups, str(time.time_ns()) + '-' + posixpath.basename(target))
    existed = True
    try:
        sftp.rename(target, previous)
    except FileNotFoundError:
        existed = False
    try:
        sftp.rename(temporary, target)
    except OSError:
        if existed:
            sftp.rename(previous, target)
        raise


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    cmd = sys.argv[1]
    client, sftp, root = connect()
    try:
        if cmd == 'ls':
            for e in sorted(sftp.listdir_attr(remote(root, sys.argv[2])), key=lambda e: e.filename):
                kind = 'd' if (e.st_mode or 0) & 0o040000 else '-'
                print(kind, f'{e.st_size or 0:>10}', e.filename)
        elif cmd == 'mkdir':
            try:
                sftp.stat(remote(root, sys.argv[2]))
                print('exists', sys.argv[2])
            except FileNotFoundError:
                sftp.mkdir(remote(root, sys.argv[2]))
                print('created', sys.argv[2])
        elif cmd == 'mv':
            sftp.rename(remote(root, sys.argv[2]), remote(root, sys.argv[3]))
            print('renamed', sys.argv[2], '->', sys.argv[3])
        elif cmd == 'get':
            sftp.get(remote(root, sys.argv[2]), sys.argv[3])
            print('downloaded', sys.argv[2], '->', sys.argv[3])
        elif cmd == 'put':
            target = remote(root, sys.argv[3])
            try:
                sftp.stat(target)
                backup = os.path.join(BACKUPS, time.strftime('%Y%m%d-%H%M%S'), target.lstrip('/'))
                os.makedirs(os.path.dirname(backup), exist_ok=True)
                sftp.get(target, backup)
                print('backed up old copy ->', backup)
            except FileNotFoundError:
                pass
            with open(sys.argv[2], 'rb') as source:
                temporary = stage_bytes(sftp, root, sys.argv[3], source.read())
            promote_staged(sftp, root, sys.argv[3], temporary)
            print('uploaded', sys.argv[2], '->', target)
        else:
            print(__doc__)
            return 2
    finally:
        sftp.close()
        client.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
