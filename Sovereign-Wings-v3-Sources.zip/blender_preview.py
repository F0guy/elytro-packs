import bpy,json,math
from pathlib import Path
from mathutils import Vector,Matrix
root=Path(r'C:/Users/lawson/Downloads/new ely files/assets/rank-wings/v3');bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
geo=json.loads((root/'geometry.json').read_text())
tex=bpy.data.images.load(str(root/'pack/assets/elytro/textures/item/sovereign_feather.png'))
m=bpy.data.materials.new('Dyeable silver feathers');m.use_nodes=True;m.surface_render_method='DITHERED';nodes=m.node_tree.nodes;bs=nodes.get('Principled BSDF');img=nodes.new('ShaderNodeTexImage');img.image=tex
mix=nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1;mix.inputs[2].default_value=(.58,.32,.86,1)
m.node_tree.links.new(img.outputs['Color'],mix.inputs[1]);m.node_tree.links.new(mix.outputs[0],bs.inputs['Base Color']);m.node_tree.links.new(img.outputs['Alpha'],bs.inputs['Alpha']);bs.inputs['Roughness'].default_value=.65
for side in [-1,1]:
 for part,els in geo.items():
  pivot=Vector((0,0,0) if part=='arm' else (10,8,-.7));fold=Matrix.Rotation(math.radians(16*side),4,'Z')
  for e in els:
   a=e['from'];b=e['to'];center=Vector([(a[i]+b[i])/2 for i in range(3)]);rot=Matrix.Rotation(math.radians(e.get('rotation',{}).get('angle',0)),4,'Z')
   verts=[];faces=[]
   # Exact front/back surfaces, including full texture alpha and native element rotation.
   for depth,reverse in [(a[2],False),(b[2],True)]:
    coords=[(a[0],b[1],depth),(a[0],a[1],depth),(b[0],a[1],depth),(b[0],b[1],depth)]
    start=len(verts)
    for c in coords:
     v=rot@(Vector(c)-center)+center-Vector((8,8,8))+pivot
     x=side*v.x*.078125;dep=v.z*.078125;f=math.radians(16*side)
     verts.append((math.cos(f)*x+math.sin(f)*dep,-math.sin(f)*x+math.cos(f)*dep,1.22+v.y*.078125))
    faces.append(tuple(range(start,start+4)))
   mesh=bpy.data.meshes.new(e['name']);mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new(e['name'],mesh);bpy.context.collection.objects.link(ob);mesh.materials.append(m)
   uv=mesh.uv_layers.new(name='UVMap')
   for poly in mesh.polygons:
    for ix,li in enumerate(poly.loop_indices):uv.data[li].uv=[(0,1),(0,0),(1,0),(1,1)][ix]
mat=bpy.data.materials.new('Charcoal mannequin');mat.diffuse_color=(.06,.065,.085,1)
for name,loc,size in [('Chestplate',(0,.13,1.18),(.65,.34,.65)),('Head',(0,.13,1.79),(.4,.4,.4)),('Left leg',(-.17,.12,.55),(.28,.3,.62)),('Right leg',(.17,.12,.55),(.28,.3,.62))]:
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=size;o.data.materials.append(mat)
bpy.ops.object.camera_add(location=(2.5,-8,3));cam=bpy.context.object;cam.rotation_euler=(Vector((0,-.15,1.2))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=4.7
for loc,power,size in [((0,-5,6),1000,5),((4,1,4),700,4)]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.data.energy=power;l.data.shape='DISK';l.data.size=size;l.rotation_euler=(Vector((0,0,1))-l.location).to_track_quat('-Z','Y').to_euler()
s=bpy.context.scene;s.camera=cam;s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=True;s.world.color=(.12,.12,.14);s.render.resolution_x=960;s.render.resolution_y=720;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.filepath=str(root/'Sovereign-Wings-v3-preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(root/'Sovereign-Wings-v3.blend'));bpy.ops.render.render(write_still=True)
