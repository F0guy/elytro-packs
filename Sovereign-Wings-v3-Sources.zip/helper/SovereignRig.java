package com.elytro.wingrig;

import com.comphenix.protocol.*;
import com.comphenix.protocol.events.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import java.util.*;
import java.util.concurrent.*;

/** Reloadable transport helper, NOT a Bukkit plugin. Skin, colors and animation stay in Skript. */
public final class SovereignRig implements AutoCloseable {
    private record Rig(Player owner, List<ItemDisplay> wings) {}
    private final Plugin plugin;
    private final ProtocolManager protocol;
    private final Map<Integer,Rig> rigs=new ConcurrentHashMap<>();
    private final Set<Integer> riders=ConcurrentHashMap.newKeySet();
    private final Map<String,int[]> base=new ConcurrentHashMap<>();
    private final PacketListener listener;
    private final BukkitTask tick;
    private int ticks;
    public SovereignRig(Plugin plugin) {
        this.plugin=plugin;protocol=ProtocolLibrary.getProtocolManager();
        var types=new ArrayList<PacketType>();types.add(PacketType.Play.Server.MOUNT);types.add(PacketType.Play.Server.SPAWN_ENTITY);
        for(var type:PacketType.values()){
            if(type.getProtocol()!=PacketType.Protocol.PLAY||type.getSender()!=PacketType.Sender.SERVER||!type.isSupported())continue;
            String n=type.name();
            if(n.equals("REL_ENTITY_MOVE")||n.equals("REL_ENTITY_MOVE_LOOK")||n.equals("ENTITY_LOOK")||n.equals("ENTITY_TELEPORT")||n.equals("ENTITY_MOVE_LOOK")||n.contains("POSITION_SYNC"))types.add(type);
        }
        listener=new PacketAdapter(plugin,ListenerPriority.HIGHEST,types){
            @Override public void onPacketSending(PacketEvent e){
                var packet=e.getPacket();if(packet.getIntegers().size()==0)return;
                int id=packet.getIntegers().read(0);
                if(e.getPacketType()==PacketType.Play.Server.MOUNT){
                    Rig rig=rigs.get(id);
                    int[] current=packet.getIntegerArrays().read(0);
                    int[] other=Arrays.stream(current).filter(x->!riders.contains(x)).toArray();
                    base.put(key(e.getPlayer(),id),other);
                    if(base.size()>10000)base.clear();
                    if(rig==null)return;
                    int[] ours=rig.wings.stream().filter(Entity::isValid).mapToInt(Entity::getEntityId).toArray();
                    int[] merged=merge(other,ours);
                    if(!Arrays.equals(current,merged)){var copy=packet.shallowClone();copy.getIntegerArrays().write(0,merged);e.setPacket(copy);}
                }else if(e.getPacketType()==PacketType.Play.Server.SPAWN_ENTITY){
                    if(!riders.contains(id))return;
                    Player viewer=e.getPlayer();
                    Bukkit.getScheduler().runTaskLater(plugin,()->{for(var r:rigs.values())if(r.wings.stream().anyMatch(d->d.getEntityId()==id))send(viewer,r,true);},1L);
                }else if(riders.contains(id))e.setCancelled(true);
            }
        };
        protocol.addPacketListener(listener);
        tick=Bukkit.getScheduler().runTaskTimer(plugin,()->{
            ticks++;
            for(var rig:new ArrayList<>(rigs.values())){
                if(!rig.owner.isOnline()||rig.owner.isDead()||rig.wings.stream().anyMatch(d->!d.isValid()||d.getWorld()!=rig.owner.getWorld())){detach(rig.owner);continue;}
                if(ticks%10==0){
                    // Tracking copy follows only on the server. Client movement packets are suppressed.
                    for(var d:rig.wings){var at=rig.owner.getLocation();at.setYaw(0);at.setPitch(0);d.teleport(at);}
                    for(var viewer:rig.owner.getWorld().getPlayers())if(viewer.canSee(rig.owner)&&rig.wings.stream().allMatch(viewer::canSee))send(viewer,rig,true);
                }
            }
        },1L,1L);
    }
    private static String key(Player viewer,int owner){return viewer.getUniqueId()+":"+owner;}
    private static int[] merge(int[] a,int[] b){return java.util.stream.IntStream.concat(Arrays.stream(a),Arrays.stream(b)).distinct().toArray();}
    private void send(Player viewer,Rig rig,boolean include){
        if(!viewer.isOnline()||viewer.getWorld()!=rig.owner.getWorld())return;
        int id=rig.owner.getEntityId();
        int[] real=rig.owner.getPassengers().stream().mapToInt(Entity::getEntityId).toArray();
        int[] existing=base.getOrDefault(key(viewer,id),new int[0]);
        int[] all=merge(existing,real);
        if(include)all=merge(all,rig.wings.stream().filter(Entity::isValid).filter(viewer::canSee).mapToInt(Entity::getEntityId).toArray());
        var packet=protocol.createPacket(PacketType.Play.Server.MOUNT);packet.getIntegers().write(0,id);packet.getIntegerArrays().write(0,all);
        protocol.sendServerPacket(viewer,packet,false);
    }
    public void attach(Player owner,Collection<ItemDisplay> displays){
        detach(owner);var wingList=List.copyOf(displays);if(wingList.size()!=4)throw new IllegalArgumentException("Expected four wing segments");
        for(var d:wingList){riders.add(d.getEntityId());d.setRotation(0,0);d.setTeleportDuration(0);}
        var rig=new Rig(owner,wingList);rigs.put(owner.getEntityId(),rig);
        for(var viewer:owner.getWorld().getPlayers())send(viewer,rig,true);
    }
    public void detach(Player owner){
        Rig rig=rigs.remove(owner.getEntityId());if(rig==null)return;
        for(var viewer:owner.getWorld().getPlayers())send(viewer,rig,false);
        for(var d:rig.wings)riders.remove(d.getEntityId());

    }
    public double mountHeight(Player owner,ItemDisplay display){
        try{
            Object p=owner.getClass().getMethod("getHandle").invoke(owner);
            Object d=display.getClass().getMethod("getHandle").invoke(display);
            for(var method:p.getClass().getMethods())if(method.getName().equals("getPassengerRidingPosition")&&method.getParameterCount()==1){
                Object v=method.invoke(p,d);return v.getClass().getField("y").getDouble(v)-owner.getY();
            }
        }catch(ReflectiveOperationException ignored){}
        return owner.getHeight();
    }
    public int count(){return rigs.size();}
    public boolean isMounted(Player owner){return rigs.containsKey(owner.getEntityId());}
    @Override public void close(){
        tick.cancel();for(var r:new ArrayList<>(rigs.values()))detach(r.owner);
        protocol.removePacketListener(listener);riders.clear();base.clear();
    }
}
