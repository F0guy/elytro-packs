from pathlib import Path
import math,json
from PIL import Image,ImageDraw
root=Path('assets/rank-wings/v3');pack=root/'pack'
parts={'arm':[],'hand':[]}
def box(part,name,c,size,angle=0,tint=0):
 # Coordinates are authored in world-like model units, at a real shoulder/wrist hinge.
 pivot=(0,0,0) if part=='arm' else (10,8,-.7)
 x,y,z=[c[i]-pivot[i]+8 for i in range(3)]
 e={'name':name,'from':[round(x-size[0]/2,4),round(y-size[1]/2,4),round(z-size[2]/2,4)],'to':[round(x+size[0]/2,4),round(y+size[1]/2,4),round(z+size[2]/2,4)],'faces':{f:{'uv':[0,0,16,16] if f in ['north','south'] else [0,15,1,16],'texture':'#feather','tintindex':tint} for f in ['north','south','east','west','up','down']}}
 if abs(angle)>.01:e['rotation']={'origin':[x,y,z],'axis':'z','angle':round(max(-45,min(45,angle)),4),'rescale':False}
 assert all(-16<=n<=32 for n in e['from']+e['to']),(name,e)
 parts[part].append(e)
def feather(part,name,start,end,width,depth,layer):
 dx=end[0]-start[0];dy=end[1]-start[1];length=math.hypot(dx,dy)
 # Long-Y cuboids, tapered across 5 overlapping sections, with a curved hooked tip.
 angle=math.degrees(math.atan2(-dx,dy))
 # Negative-Y feather direction; reverse local orientation to keep the supported angle in range.
 if angle>90:angle-=180
 if angle<-90:angle+=180
 t=.5
 cx=start[0]+dx*t;cy=start[1]+dy*t;cz=(start[2]+end[2])/2
 box(part,name,(cx,cy,cz),(width,length,depth*.3),angle)
 # Alpha-cut feather blades carry the fine curved barbs; no rectangular segmented tips.
 parts[part][-1]['faces']={k:v for k,v in parts[part][-1]['faces'].items() if k in ('north','south')}
 # Tiny fluffy edge feathers break up the coverts' outline.
for j in range(11):
 t=j/10;x=1.6+11*t;y=1+8*math.sin(t*math.pi/2);z=-.15-.7*t
 part='arm' if x<9.5 else 'hand'
 feather(part,f'inner layered flight feather {j}',(x,y,z),(x+2.0+2*t,y-7-7*t,z+.7),2.5,.7,0)
for j in range(11):
 t=j/10;x=10+10.8*t;y=8.6-3.6*t*t;z=-.8-2.6*t*t
 # The longest outer feathers curl back inward and behind the wearer.
 feather('hand',f'curved outer primary {j}',(x,y,z),(x+4.0-8.5*t,y-14.5+1.5*t,z-2.2-1.3*t),3.0,.75,0)
for row in range(3):
 for j in range(13):
  t=j/12;x=1+19.5*t;y=1+8.5*math.sin(t*math.pi*.8)-row*1.65;z=-.6-row*.34-2*t*t
  part='arm' if x<9.6 else 'hand'
  feather(part,f'fluffy covert {row}-{j}',(x,y,z),(x+.7-1.8*t,y-3.4-row*.25,z-.1),2.25,.6,1)
for j in range(8):
 t=j/7
 feather('arm',f'shoulder down {j}',(.2+2.3*t,1+5*t,-.5),(-.4+2*t,-2.5+5*t,-.9),1.6,.75,1)
for part,els in parts.items():
 m={'textures':{'feather':'elytro:item/sovereign_feather','particle':'elytro:item/sovereign_feather'},'gui_light':'front','elements':els}
 d={'model':{'type':'minecraft:model','model':f'elytro:item/sovereign_wing_{part}','tints':[{'type':'minecraft:dye','default':int('B47FF0',16)},{'type':'minecraft:dye','default':int('B47FF0',16)}]}}
 for n,b in [(f'assets/elytro/models/item/sovereign_wing_{part}.json',m),(f'assets/elytro/items/sovereign_wing_{part}.json',d)]:
  p=pack/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(b,separators=(',',':')),encoding='utf-8')
# New neutral, finely barbed material: color is controlled entirely by the item dye.
im=Image.new('RGBA',(128,256),(0,0,0,0));px=im.load()
for y in range(256):
 t=y/255
 center=63.5+9*math.sin(t*math.pi)
 half=58*(max(0,math.sin(t*math.pi))**.58)*(1-.3*t)
 # Fine feather barbs give a fluffy outline instead of a hard polygon edge.
 half += 1.8*math.sin(y*2.4)
 for x in range(128):
  dist=abs(x-center)
  if dist<=half and half>0:
   ridge=math.cos((y+dist*.9)*1.9)*5
   val=int(min(255,max(0,225+22*(1-dist/half)+ridge)))
   px[x,y]=(val,val,val,255)
draw=ImageDraw.Draw(im)
points=[(63.5+9*math.sin(y/255*math.pi),y) for y in range(8,247)]
draw.line(points,fill=(255,255,255,255),width=2)
p=pack/'assets/elytro/textures/item/sovereign_feather.png';p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
(root/'geometry.json').write_text(json.dumps(parts))
print('Curved layered feather geometry:',{k:len(v) for k,v in parts.items()})
